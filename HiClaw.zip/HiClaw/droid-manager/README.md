# droid-manager

**Droid Factory CLI runtime for the HiClaw Manager** — a drop-in replacement for the
OpenClaw / CoPaw harnesses that drives the Manager loop with
[Factory.ai Droid CLI](https://docs.factory.ai/welcome) via its `droid exec`
JSON-RPC streaming protocol.

It plugs into HiClaw the same way `copaw-worker` does:

```text
HICLAW_MANAGER_RUNTIME=droid  →  start-manager-agent.sh → start-droid-manager.sh
                                                                 │
                                                                 ▼
                                            MatrixChannel (matrix-nio)
                                                                 │
                                                                 ▼
                                            DroidHarness ── stdin/stdout ──▶
                                            `droid exec --input-format stream-jsonrpc
                                                        --output-format stream-jsonrpc`
```

The harness implements the JSON-RPC vocabulary documented in
[Droid Exec → stdin/stdout behavior for raw JSON-RPC](https://docs.factory.ai/cli/droid-exec/overview):

| Direction                  | Method                          | Purpose                                      |
| -------------------------- | ------------------------------- | -------------------------------------------- |
| client → droid (request)   | `droid.initialize_session`      | Open or attach a session for a Matrix room   |
| client → droid (request)   | `droid.load_session`            | Resume an existing session by id             |
| client → droid (request)   | `droid.add_user_message`        | Forward a Matrix message into the agent      |
| droid → client (notify)    | `droid.session_notification`    | Stream assistant deltas, tool events, errors |
| droid → client (request)   | `droid.request_permission`      | Approval prompt for risky tool calls         |
| droid → client (request)   | `droid.ask_user`                | Out-of-band question for the user            |

The bridge maps each Matrix room (or DM) to a **persistent droid session**, persists
the session id under `${HOME}/.droid-manager/sessions/<room>.json`, and reconnects
seamlessly across container restarts.

## Why it exists

HiClaw's stock Manager runs `openclaw gateway run` — a Node.js gateway with a
built-in `@matrix-org/matrix-sdk-crypto-nodejs` native addon and its own model
gateway. We replace just the *harness layer* while keeping every other HiClaw
contract intact:

- Matrix homeserver / token / E2EE flags are read from `openclaw.json` (same file).
- Allowlist / `requireMention` / `groups{}` policy is preserved verbatim.
- The Manager's filesystem layout (`~/manager-workspace`, `SOUL.md`,
  `HEARTBEAT.md`, `TOOLS.md`, `skills/`, `memory/`, `hiclaw-fs/`) is the working
  directory passed to `droid exec --cwd`.
- The Manager continues to assign work via Matrix to existing OpenClaw / CoPaw /
  Hermes **Workers**. Only the Manager's brain changes.

## Quick start (local Docker)

```bash
# 1. Build the manager-droid image
make manager-droid

# 2. Bring up the embedded stack with the droid runtime
hiclaw-install.sh \
    --manager-runtime droid \
    --droid-api-key "$FACTORY_API_KEY" \
    --droid-model "claude-sonnet-4-6" \
    --droid-auto medium
```

## Quick start (Helm)

```bash
helm install hiclaw ./helm/hiclaw \
    --set manager.runtime=droid \
    --set manager.droid.apiKey=$FACTORY_API_KEY \
    --set manager.droid.model=claude-sonnet-4-6 \
    --set manager.droid.autoLevel=medium
```

## Configuration

`droid-manager` reads the **same** `openclaw.json` the OpenClaw harness reads.
A new optional section `runtime.droid` controls Droid-specific behavior:

```jsonc
{
  "runtime": {
    "droid": {
      "binary": "droid",                          // override path
      "model": "claude-sonnet-4-6",               // -m
      "specModel": "claude-haiku-4-5",            // --spec-model
      "reasoningEffort": "medium",                // -r
      "autoLevel": "medium",                      // --auto low|medium|high
      "mission": false,                           // --mission
      "appendSystemPromptFile": "/root/manager-workspace/SOUL.md",
      "cwd": "/root/manager-workspace",           // --cwd
      "enabledTools": [],                         // --enabled-tools
      "disabledTools": [],
      "tags": ["hiclaw", "manager"],              // --tag (repeatable)
      "logGroupId": "hiclaw-manager",
      "skipPermissionsUnsafe": false,
      "sessionDir": "~/.droid-manager/sessions",
      "stallTimeoutSeconds": 1800
    }
  }
}
```

Required environment variable: `FACTORY_API_KEY` (the harness exports it before
spawning `droid exec`).

## Architecture

```
                ┌────────────────────────────────────────────────┐
                │              HiClaw Manager container          │
                │                                                │
   Matrix ─────►│  MatrixChannel  ────────►  DroidHarness  ───── │ ─► droid exec
   (Tuwunel)    │  (matrix-nio)              (stream-jsonrpc)    │    (one subprocess
                │                                                │     per session*)
                │  openclaw.json reader  ───►  DroidConfig       │
                │  Manager workspace      ───►  --cwd, SOUL.md   │
                └────────────────────────────────────────────────┘
```

\* You can run one `droid exec` process per room (default, isolated context) or a
single process multiplexed across rooms via `droid.fork`. The default is per-room.

## Layout

```
droid-manager/
├── pyproject.toml
├── README.md
├── Dockerfile
├── scripts/
│   ├── start-droid-manager.sh   # called by start-manager-agent.sh when runtime=droid
│   └── install-droid-cli.sh     # install Factory CLI in the image
├── src/
│   └── droid_manager/
│       ├── __init__.py
│       ├── __main__.py          # python -m droid_manager
│       ├── bridge.py            # openclaw.json -> droid runtime config
│       ├── config.py            # DroidConfig dataclass
│       ├── harness.py           # subprocess + JSON-RPC stream wrapper
│       ├── matrix_channel.py    # thin wrapper over copaw matrix channel
│       ├── manager.py           # main loop: Matrix <-> Harness routing
│       ├── session_store.py     # per-room session id persistence
│       └── templates/
│           └── runtime.droid.json
└── tests/
    ├── test_config.py
    ├── test_harness.py
    └── test_session_store.py
```

## License

Apache-2.0, inherits from HiClaw.
