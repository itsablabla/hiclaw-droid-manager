#!/bin/bash
# start-droid-manager.sh — Start the Manager Agent with the Droid runtime.
# Called by start-manager-agent.sh when HICLAW_MANAGER_RUNTIME=droid.
#
# Mirrors start-copaw-manager.sh: bridge openclaw.json into a runtime-specific
# working directory, then exec the long-running runtime as PID 1 of its
# supervisord program.

set -euo pipefail

# Pull in the same env helpers as the other start scripts.
if [ -f /opt/hiclaw/scripts/lib/hiclaw-env.sh ]; then
    # shellcheck disable=SC1091
    source /opt/hiclaw/scripts/lib/hiclaw-env.sh
else
    # Fallback log shim when running outside the HiClaw image.
    log() { printf "%s [droid-manager] %s\n" "$(date -u +%FT%TZ)" "$*"; }
fi

OPENCLAW_WORKSPACE="${HOME:-/root/manager-workspace}"
OPENCLAW_JSON="${OPENCLAW_WORKSPACE}/openclaw.json"
DROID_WORKING_DIR="${HOME}/.droid-manager"

if [ ! -f "${OPENCLAW_JSON}" ]; then
    log "ERROR: openclaw.json not found at ${OPENCLAW_JSON}"
    exit 1
fi

mkdir -p "${DROID_WORKING_DIR}/sessions"

# ---- 1. Verify Factory API key ----------------------------------------------
if [ -z "${FACTORY_API_KEY:-}" ]; then
    log "WARNING: FACTORY_API_KEY is unset. The droid CLI will fail to call"
    log "         Factory's gateway. Generate a key at"
    log "         https://app.factory.ai/settings/api-keys and export it via"
    log "         HICLAW_DROID_API_KEY or FACTORY_API_KEY."
fi
if [ -n "${HICLAW_DROID_API_KEY:-}" ] && [ -z "${FACTORY_API_KEY:-}" ]; then
    export FACTORY_API_KEY="${HICLAW_DROID_API_KEY}"
fi

# ---- 2. Verify droid binary is on PATH --------------------------------------
if ! command -v droid >/dev/null 2>&1; then
    log "ERROR: droid CLI not found on PATH."
    log "       Run scripts/install-droid-cli.sh during image build."
    exit 1
fi
DROID_VERSION="$(droid --version 2>&1 | head -1 || true)"
log "droid binary: $(command -v droid) (${DROID_VERSION})"

# ---- 3. Bridge openclaw.json into runtime.droid.json (debug aid) ------------
log "Bridging openclaw.json -> droid runtime config..."
PYTHONPATH="/opt/hiclaw/droid-manager/src:${PYTHONPATH:-}" \
    python3 -m droid_manager.bridge \
        --openclaw-json "${OPENCLAW_JSON}" \
        --working-dir "${DROID_WORKING_DIR}" || {
    log "bridge step failed; manager will still try to start from openclaw.json"
}

# ---- 4. Sync prompt files into the droid cwd --------------------------------
# Same convention as start-copaw-manager.sh: AGENTS.md, SOUL.md, HEARTBEAT.md,
# TOOLS.md, USER.md, MEMORY.md, plus memory/ and skills/ are kept under the
# Manager workspace and exposed to droid via --cwd.
for _f in AGENTS.md SOUL.md HEARTBEAT.md TOOLS.md USER.md MEMORY.md; do
    [ -f "${OPENCLAW_WORKSPACE}/${_f}" ] || continue
    # files already live in cwd; no-op but log presence
    log "  prompt asset present: ${_f}"
done

# ---- 5. Background watcher: re-bridge when openclaw.json changes ------------
(
    _prev=$(md5sum "${OPENCLAW_JSON}" 2>/dev/null | awk '{print $1}')
    while true; do
        sleep 60
        _curr=$(md5sum "${OPENCLAW_JSON}" 2>/dev/null | awk '{print $1}')
        if [ -n "${_curr}" ] && [ "${_curr}" != "${_prev}" ]; then
            log "openclaw.json changed, re-bridging..."
            PYTHONPATH="/opt/hiclaw/droid-manager/src:${PYTHONPATH:-}" \
                python3 -m droid_manager.bridge \
                    --openclaw-json "${OPENCLAW_JSON}" \
                    --working-dir "${DROID_WORKING_DIR}" >/dev/null 2>&1 || true
            _prev="${_curr}"
        fi
    done
) &
WATCHER_PID=$!
log "openclaw.json watcher started (pid=${WATCHER_PID})"

# ---- 6. Launch the Droid Manager --------------------------------------------
export OPENCLAW_CONFIG_PATH="${OPENCLAW_JSON}"
export DROID_MANAGER_WORKING_DIR="${DROID_WORKING_DIR}"
export PYTHONPATH="/opt/hiclaw/droid-manager/src:${PYTHONPATH:-}"

log "Starting droid-manager runtime..."
exec python3 -m droid_manager \
    --openclaw-json "${OPENCLAW_JSON}" \
    --log-level "${DROID_MANAGER_LOG_LEVEL:-INFO}"
