#!/bin/bash
# install-droid-cli.sh — Install the Factory.ai Droid CLI inside the Manager
# image. Called from droid-manager/Dockerfile and the embedded controller.
#
# Source of truth for the install command:
# https://docs.factory.ai/cli/getting-started/quickstart
#
# We prefer the npm install for image builds because it avoids piping a
# remote shell script into bash and gives us a pinnable version.
set -euo pipefail

DROID_VERSION="${DROID_VERSION:-latest}"

if command -v droid >/dev/null 2>&1; then
    echo "droid already installed: $(droid --version 2>&1 || true)"
    exit 0
fi

if command -v npm >/dev/null 2>&1; then
    echo "==> Installing droid via npm ($DROID_VERSION)..."
    npm install -g "droid@${DROID_VERSION}" --no-fund --no-audit
elif command -v curl >/dev/null 2>&1; then
    echo "==> Installing droid via Factory CLI install script..."
    curl -fsSL https://app.factory.ai/cli | sh
    # The installer drops the binary under ~/.factory/bin; ensure it's on PATH.
    if [ -d "$HOME/.factory/bin" ] && ! command -v droid >/dev/null 2>&1; then
        ln -sf "$HOME/.factory/bin/droid" /usr/local/bin/droid
    fi
else
    echo "ERROR: neither npm nor curl available to install droid CLI" >&2
    exit 1
fi

droid --version || {
    echo "ERROR: droid did not install correctly" >&2
    exit 1
}
