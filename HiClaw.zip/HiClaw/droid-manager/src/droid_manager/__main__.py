"""``python -m droid_manager`` entrypoint.

Usage::

    droid-manager [--openclaw-json PATH] [--log-level LEVEL]

If ``--openclaw-json`` is omitted, the manager reads ``OPENCLAW_CONFIG_PATH``
(set by ``start-manager-agent.sh``) or falls back to
``~/manager-workspace/openclaw.json``.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

from .manager import DEFAULT_OPENCLAW_JSON, run


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="droid-manager")
    parser.add_argument(
        "--openclaw-json",
        default=os.environ.get("OPENCLAW_CONFIG_PATH") or DEFAULT_OPENCLAW_JSON,
        help="Path to the HiClaw openclaw.json configuration file.",
    )
    parser.add_argument(
        "--log-level",
        default=os.environ.get("DROID_MANAGER_LOG_LEVEL", "INFO"),
        help="Python logging level (default: INFO).",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=args.log_level.upper(),
        format="%(asctime)s %(levelname)-5s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    try:
        run(args.openclaw_json)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logging.getLogger("droid_manager").exception("fatal: %s", exc)
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
