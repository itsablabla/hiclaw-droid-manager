"""matrix-nio Matrix transport for the Droid Manager.

A focused subset of HiClaw's CoPaw ``MatrixChannel`` — extracted so the
Droid Manager runs without a hard dependency on ``copaw`` or ``qwenpaw``.
It covers what the Manager actually needs:

* Login via ``access_token`` (whoami → user_id, device_id, optional crypto store).
* Auto-join invited rooms.
* Allowlist enforcement for DMs and group rooms.
* Per-room ``requireMention`` policy.
* Long-poll ``sync_forever`` loop with persisted ``next_batch`` token.
* Markdown → HTML formatting for replies (matches OpenClaw / CoPaw).
* Simple read receipt + typing indicator UX.

Inbound messages are pushed to an ``asyncio.Queue`` that the manager loop
consumes. Outbound replies are sent via :meth:`send_reply`.
"""

from __future__ import annotations

import asyncio
import html
import logging
import os
import re
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from nio import (  # type: ignore[import-not-found]
    AsyncClient,
    AsyncClientConfig,
    MatrixRoom,
    RoomMessageText,
    SyncResponse,
    WhoamiResponse,
)
from nio.responses import JoinedMembersResponse  # type: ignore[import-not-found]

from .config import MatrixSettings

logger = logging.getLogger("droid_manager.matrix")

DM_CACHE_TTL_MS = 30_000


def _normalize_user_id(uid: str) -> str:
    uid = uid.strip().lower()
    if uid and not uid.startswith("@"):
        uid = "@" + uid
    return uid


def _md_to_html(text: str) -> str:
    """Render markdown → HTML for the Matrix ``formatted_body`` field."""
    try:
        from markdown_it import MarkdownIt

        md = MarkdownIt(
            "commonmark",
            {"html": False, "linkify": True, "breaks": True, "typographer": False},
        )
        md.enable("strikethrough")
        md.enable("table")
        try:
            from linkify_it import LinkifyIt

            md.linkify = LinkifyIt()
        except ImportError:
            pass
        return md.render(text).rstrip("\n")
    except ImportError:
        return html.escape(text).replace("\n", "<br>\n")


@dataclass
class MatrixInbound:
    """Inbound user-visible message — what we feed to the harness."""

    room_id: str
    sender_id: str
    body: str
    is_dm: bool
    event_id: str
    timestamp: Optional[int] = None
    formatted_body: Optional[str] = None


class MatrixChannel:
    """Lightweight matrix-nio runtime for the Droid Manager."""

    def __init__(
        self,
        settings: MatrixSettings,
        *,
        sync_token_path: Optional[Path] = None,
        e2ee_store_path: Optional[Path] = None,
    ) -> None:
        self._cfg = settings
        self._client: Optional[AsyncClient] = None
        self._user_id: Optional[str] = None
        self._sync_task: Optional[asyncio.Task] = None
        self._sync_token_path = sync_token_path
        self._e2ee_store_path = e2ee_store_path
        self._dm_cache: dict[str, dict[str, Any]] = {}
        self._inbound_queue: asyncio.Queue[MatrixInbound] = asyncio.Queue()
        self._allow_set = frozenset(
            _normalize_user_id(u) for u in (settings.allow_from or [])
        ) | frozenset(
            _normalize_user_id(u) for u in (settings.group_allow_from or [])
        )

    @property
    def user_id(self) -> str | None:
        return self._user_id

    @property
    def inbound(self) -> "asyncio.Queue[MatrixInbound]":
        return self._inbound_queue

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        if not self._cfg.homeserver:
            raise RuntimeError(
                "Matrix homeserver not configured — check channels.matrix in openclaw.json"
            )
        if not self._cfg.access_token:
            raise RuntimeError(
                "Matrix access_token not configured — Manager cannot connect"
            )

        store_path = None
        if self._cfg.encryption and self._e2ee_store_path:
            self._e2ee_store_path.mkdir(parents=True, exist_ok=True)
            store_path = str(self._e2ee_store_path)

        sync_s = self._cfg.sync_timeout_ms / 1000
        request_timeout = max(sync_s + 30, 60)
        client_config = AsyncClientConfig(
            store_sync_tokens=False,
            encryption_enabled=self._cfg.encryption,
            request_timeout=request_timeout,
        )
        self._client = AsyncClient(
            self._cfg.homeserver,
            user="",
            store_path=store_path or "",
            config=client_config,
        )
        self._client.access_token = self._cfg.access_token
        whoami = await self._client.whoami()
        if not isinstance(whoami, WhoamiResponse):
            raise RuntimeError(f"Matrix whoami failed: {whoami}")
        self._user_id = whoami.user_id
        self._client.user_id = whoami.user_id
        self._client.user = whoami.user_id
        if whoami.device_id:
            self._client.device_id = whoami.device_id
        logger.info(
            "matrix logged in as %s (device=%s, e2ee=%s)",
            self._user_id,
            whoami.device_id,
            self._cfg.encryption,
        )
        if self._cfg.encryption and self._client.store_path and self._client.device_id:
            self._client.load_store()
            if self._client.should_upload_keys:
                await self._client.keys_upload()

        self._client.add_event_callback(self._on_text, (RoomMessageText,))
        self._sync_task = asyncio.create_task(self._sync_loop())

    async def stop(self) -> None:
        if self._sync_task and not self._sync_task.done():
            self._sync_task.cancel()
            try:
                await self._sync_task
            except asyncio.CancelledError:
                pass
        if self._client:
            await self._client.close()

    # ------------------------------------------------------------------
    # Outbound
    # ------------------------------------------------------------------

    async def send_reply(self, room_id: str, text: str, *, html_body: str | None = None) -> None:
        """Send a markdown-formatted message into a room."""
        if not self._client:
            return
        formatted = html_body if html_body is not None else _md_to_html(text)
        content: dict[str, Any] = {
            "msgtype": "m.text",
            "body": text,
            "format": "org.matrix.custom.html",
            "formatted_body": formatted,
        }
        try:
            await self._client.room_send(
                room_id=room_id,
                message_type="m.room.message",
                content=content,
                ignore_unverified_devices=True,
            )
        except Exception as exc:
            logger.warning("matrix send_reply failed in %s: %s", room_id, exc)

    async def set_typing(self, room_id: str, typing: bool, timeout_ms: int = 30_000) -> None:
        if not self._client:
            return
        try:
            await self._client.room_typing(
                room_id, typing_state=typing, timeout=timeout_ms
            )
        except Exception as exc:
            logger.debug("typing %s failed: %s", room_id, exc)

    async def mark_read(self, room_id: str, event_id: str) -> None:
        if not self._client or not event_id:
            return
        try:
            await self._client.room_read_markers(
                room_id, fully_read_event=event_id, read_event=event_id
            )
        except Exception as exc:
            logger.debug("read_markers %s failed: %s", room_id, exc)

    # ------------------------------------------------------------------
    # Inbound dispatch
    # ------------------------------------------------------------------

    async def _on_text(self, room: MatrixRoom, event: RoomMessageText) -> None:
        if not self._user_id or event.sender == self._user_id:
            return
        room_id = room.room_id
        sender_id = event.sender
        text = event.body or ""

        is_dm = await self._is_dm_room(room_id, sender_id)

        if not self._check_allowed(sender_id, is_dm):
            return

        # Group rooms with requireMention need an @mention to wake the bot.
        if not is_dm and self._require_mention(room_id):
            if not self._was_mentioned(event, text):
                return

        # Strip leading @mention so slash commands parse cleanly downstream.
        stripped = self._strip_mention_prefix(text, room)
        if stripped.strip() == "NO_REPLY":
            return

        formatted = event.source.get("content", {}).get("formatted_body")

        await self._inbound_queue.put(
            MatrixInbound(
                room_id=room_id,
                sender_id=sender_id,
                body=stripped or text,
                is_dm=is_dm,
                event_id=event.event_id,
                timestamp=getattr(event, "server_timestamp", None),
                formatted_body=formatted,
            )
        )

    def _check_allowed(self, sender_id: str, is_dm: bool) -> bool:
        normalized = _normalize_user_id(sender_id)
        if is_dm:
            if self._cfg.dm_policy == "disabled":
                return False
            if self._cfg.dm_policy == "allowlist" and normalized not in self._allow_set:
                logger.debug("DM blocked from %s", sender_id)
                return False
        else:
            if self._cfg.group_policy == "disabled":
                return False
            if (
                self._cfg.group_policy == "allowlist"
                and normalized not in self._allow_set
            ):
                logger.debug("group msg blocked from %s", sender_id)
                return False
        return True

    def _require_mention(self, room_id: str) -> bool:
        room_cfg = self._cfg.groups.get(room_id) or self._cfg.groups.get("*")
        if room_cfg:
            if room_cfg.get("autoReply") is True:
                return False
            if "requireMention" in room_cfg:
                return bool(room_cfg["requireMention"])
        return True

    def _was_mentioned(self, event: RoomMessageText, text: str) -> bool:
        if not self._user_id:
            return False
        content = event.source.get("content", {})
        mentions = content.get("m.mentions", {})
        if self._user_id in mentions.get("user_ids", []):
            return True
        if mentions.get("room"):
            return True
        formatted_body = content.get("formatted_body", "") or ""
        if self._user_id:
            escaped = re.escape(self._user_id)
            if re.search(
                rf'href=["\']https://matrix\.to/#/{escaped}["\']',
                formatted_body,
                re.IGNORECASE,
            ):
                return True
            encoded = re.escape(urllib.parse.quote(self._user_id))
            if re.search(
                rf'href=["\']https://matrix\.to/#/{encoded}["\']',
                formatted_body,
                re.IGNORECASE,
            ):
                return True
            if re.search(re.escape(self._user_id), text, re.IGNORECASE):
                return True
        return False

    def _strip_mention_prefix(self, text: str, room: MatrixRoom) -> str:
        if not self._user_id:
            return text
        escaped = re.escape(self._user_id)
        result = re.sub(rf"^{escaped}\s*:?\s*", "", text, flags=re.IGNORECASE)
        if result != text:
            return result.strip()
        try:
            display = room.user_name(self._user_id) or ""
        except Exception:
            display = ""
        if display and display != self._user_id:
            result = re.sub(
                rf"^{re.escape(display)}\s*:?\s*", "", text, flags=re.IGNORECASE
            )
            if result != text:
                result = re.sub(r"^[^\w/]+", "", result)
                return result.strip()
        localpart = self._user_id.split(":")[0].lstrip("@")
        if localpart:
            result = re.sub(
                rf"^{re.escape(localpart)}\s*:?\s*",
                "",
                text,
                flags=re.IGNORECASE,
            )
            if result != text:
                result = re.sub(r"^[^\w/]+", "", result)
                return result.strip()
        return text

    # ------------------------------------------------------------------
    # DM detection (Matrix API)
    # ------------------------------------------------------------------

    async def _is_dm_room(self, room_id: str, sender_id: str) -> bool:
        if not self._client or not self._user_id:
            return False
        now = int(time.time() * 1000)
        cached = self._dm_cache.get(room_id)
        if cached and (now - cached["ts"]) < DM_CACHE_TTL_MS:
            members = cached["members"]
            return (
                len(members) == 2
                and self._user_id in members
                and sender_id in members
            )
        try:
            resp = await self._client.joined_members(room_id)
            if isinstance(resp, JoinedMembersResponse):
                members = [m.user_id for m in resp.members]
                self._dm_cache[room_id] = {"members": members, "ts": now}
                return (
                    len(members) == 2
                    and self._user_id in members
                    and sender_id in members
                )
        except Exception as exc:
            logger.debug("joined_members %s failed: %s", room_id, exc)
        return False

    # ------------------------------------------------------------------
    # Sync loop with persisted next_batch token
    # ------------------------------------------------------------------

    def _load_token(self) -> Optional[str]:
        if not self._sync_token_path or not self._sync_token_path.is_file():
            return None
        try:
            return self._sync_token_path.read_text(encoding="utf-8").strip() or None
        except OSError:
            return None

    def _save_token(self, token: str) -> None:
        if not self._sync_token_path:
            return
        try:
            self._sync_token_path.parent.mkdir(parents=True, exist_ok=True)
            self._sync_token_path.write_text(token, encoding="utf-8")
        except OSError as exc:
            logger.debug("sync token write failed: %s", exc)

    async def _e2ee_maintenance(self) -> None:
        if not self._cfg.encryption or not self._client or not self._client.olm:
            return
        try:
            if self._client.should_upload_keys:
                await self._client.keys_upload()
            if self._client.should_query_keys:
                await self._client.keys_query()
            if self._client.should_claim_keys:
                await self._client.keys_claim(
                    self._client.get_users_for_key_claiming()
                )
            await self._client.send_to_device_messages()
        except Exception as exc:
            logger.debug("e2ee maintenance error: %s", exc)

    async def _sync_loop(self) -> None:
        assert self._client is not None
        next_batch = self._load_token()
        if next_batch is None:
            # First-boot catch-up: suppress callbacks so we don't replay history.
            saved_cbs = self._client.event_callbacks[:]
            self._client.event_callbacks.clear()
            try:
                resp = await self._client.sync(
                    timeout=self._cfg.sync_timeout_ms, full_state=True
                )
            finally:
                self._client.event_callbacks.extend(saved_cbs)
            if isinstance(resp, SyncResponse):
                next_batch = resp.next_batch
                if next_batch:
                    self._save_token(next_batch)
                if self._cfg.auto_join == "always":
                    for invited in resp.rooms.invite:
                        logger.info("auto-joining %s", invited)
                        await self._client.join(invited)
                await self._e2ee_maintenance()

        while True:
            try:
                resp = await self._client.sync(
                    timeout=self._cfg.sync_timeout_ms,
                    since=next_batch,
                    full_state=False,
                )
                if isinstance(resp, SyncResponse):
                    next_batch = resp.next_batch
                    if next_batch:
                        self._save_token(next_batch)
                    if self._cfg.auto_join == "always":
                        for invited in resp.rooms.invite:
                            logger.info("auto-joining %s", invited)
                            await self._client.join(invited)
                    await self._e2ee_maintenance()
                else:
                    logger.warning("sync error: %s", resp)
                    await asyncio.sleep(5)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.exception("sync loop exception: %s", exc)
                await asyncio.sleep(5)
