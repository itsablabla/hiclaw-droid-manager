"""Droid Factory CLI runtime for the HiClaw Manager.

A drop-in replacement for the OpenClaw harness that drives the Manager loop
with ``droid exec --input-format stream-jsonrpc --output-format stream-jsonrpc``.
"""

from .config import DroidConfig, MatrixSettings, RuntimeConfig
from .harness import DroidHarness, HarnessEvent, HarnessRequest
from .session_store import SessionStore

# Note: ``DroidManager`` is imported lazily because it depends on
# ``matrix-nio`` (which depends on libolm for E2EE). Importing the package
# in test or tooling environments without those deps should still work.


def __getattr__(name):  # pragma: no cover - thin attribute proxy
    if name == "DroidManager":
        from .manager import DroidManager as _DroidManager
        return _DroidManager
    raise AttributeError(f"module 'droid_manager' has no attribute {name!r}")


__all__ = [
    "DroidConfig",
    "DroidHarness",
    "DroidManager",
    "HarnessEvent",
    "HarnessRequest",
    "MatrixSettings",
    "RuntimeConfig",
    "SessionStore",
]

__version__ = "0.1.0"
