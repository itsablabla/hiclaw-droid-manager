"""Configuration loader for the Droid Manager.

Reads the existing HiClaw ``openclaw.json`` template (the same file the
OpenClaw and CoPaw harnesses consume) and extracts:

* The Matrix channel settings (homeserver, access token, allowlist, etc.).
* The Droid-specific runtime block at ``runtime.droid`` (optional).

This means a stock HiClaw install needs **no schema change** to switch to
the Droid harness — operators just set ``HICLAW_MANAGER_RUNTIME=droid`` and
optionally drop a ``runtime.droid`` block into their config.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

DEFAULT_BINARY = "droid"
DEFAULT_AUTO_LEVEL = "medium"
DEFAULT_REASONING = "medium"
DEFAULT_STALL_TIMEOUT = 1800  # seconds — match openclaw timeoutSeconds default
DEFAULT_SESSION_DIR = "~/.droid-manager/sessions"


def _expand(path: str | os.PathLike[str]) -> Path:
    """Expand ``~`` and environment variables in a path."""
    return Path(os.path.expandvars(os.path.expanduser(str(path))))


def _as_list(value: Any) -> list[str]:
    """Coerce a JSON value to ``list[str]`` (drops ``None`` and empties)."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value else []
    if isinstance(value, Iterable):
        return [str(v) for v in value if str(v)]
    return [str(value)]


@dataclass
class MatrixSettings:
    """Subset of ``channels.matrix`` we need to drive matrix-nio."""

    homeserver: str = ""
    access_token: str = ""
    user_id: str = ""
    encryption: bool = False

    dm_policy: str = "allowlist"
    allow_from: list[str] = field(default_factory=list)
    group_policy: str = "allowlist"
    group_allow_from: list[str] = field(default_factory=list)
    groups: dict[str, Any] = field(default_factory=dict)
    auto_join: str = "always"

    sync_timeout_ms: int = 30_000
    history_limit: int = 50

    @classmethod
    def from_openclaw(cls, raw: dict[str, Any]) -> "MatrixSettings":
        """Map ``openclaw.json:channels.matrix`` onto our dataclass."""
        m = (raw.get("channels") or {}).get("matrix") or {}
        # OpenClaw uses ``accessToken`` (camelCase) while copaw bridge writes
        # ``access_token`` (snake_case). Accept either to stay drop-in.
        token = m.get("accessToken") or m.get("access_token") or ""
        return cls(
            homeserver=m.get("homeserver", ""),
            access_token=token,
            user_id=m.get("userId") or m.get("user_id") or "",
            encryption=bool(m.get("encryption", False)),
            dm_policy=(m.get("dm") or {}).get("policy", "allowlist"),
            allow_from=_as_list((m.get("dm") or {}).get("allowFrom")),
            group_policy=m.get("groupPolicy", "allowlist"),
            group_allow_from=_as_list(m.get("groupAllowFrom")),
            groups=m.get("groups") or {},
            auto_join=m.get("autoJoin", "always"),
            sync_timeout_ms=int(m.get("syncTimeoutMs", 30_000)),
            history_limit=int(m.get("historyLimit", 50)),
        )


@dataclass
class DroidConfig:
    """Droid CLI invocation settings (one harness ≅ one ``droid exec`` proc)."""

    binary: str = DEFAULT_BINARY
    model: str | None = None
    spec_model: str | None = None
    reasoning_effort: str = DEFAULT_REASONING
    spec_reasoning_effort: str | None = None
    auto_level: str = DEFAULT_AUTO_LEVEL
    use_spec: bool = False
    mission: bool = False
    worker_model: str | None = None
    worker_reasoning_effort: str | None = None
    validator_model: str | None = None
    validator_reasoning_effort: str | None = None

    cwd: Path = field(default_factory=lambda: _expand("~"))
    append_system_prompt_file: Path | None = None
    append_system_prompt: str | None = None
    enabled_tools: list[str] = field(default_factory=list)
    disabled_tools: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    log_group_id: str | None = None
    skip_permissions_unsafe: bool = False

    session_dir: Path = field(default_factory=lambda: _expand(DEFAULT_SESSION_DIR))
    stall_timeout_seconds: int = DEFAULT_STALL_TIMEOUT
    api_key_env: str = "FACTORY_API_KEY"

    @classmethod
    def from_openclaw(cls, raw: dict[str, Any]) -> "DroidConfig":
        """Read the optional ``runtime.droid`` block from ``openclaw.json``.

        Missing keys fall back to environment overrides (``HICLAW_DROID_*``)
        and then to sensible defaults. This means a stock OpenClaw config
        with no droid section still produces a runnable harness.
        """
        env = os.environ
        runtime = (raw.get("runtime") or {}).get("droid") or {}

        def _env(name: str, default: Any = None) -> Any:
            return env.get(name, default)

        cwd_raw = runtime.get("cwd") or _env("HICLAW_DROID_CWD") or "~/manager-workspace"
        prompt_path = runtime.get("appendSystemPromptFile") or _env(
            "HICLAW_DROID_PROMPT_FILE"
        )
        # Default to ``SOUL.md`` under cwd so the Manager keeps its prompt.
        if not prompt_path:
            soul = _expand(cwd_raw) / "SOUL.md"
            if soul.is_file():
                prompt_path = str(soul)

        session_dir_raw = runtime.get("sessionDir") or _env(
            "HICLAW_DROID_SESSION_DIR", DEFAULT_SESSION_DIR
        )

        return cls(
            binary=runtime.get("binary") or _env("HICLAW_DROID_BIN", DEFAULT_BINARY),
            model=runtime.get("model") or _env("HICLAW_DROID_MODEL"),
            spec_model=runtime.get("specModel") or _env("HICLAW_DROID_SPEC_MODEL"),
            reasoning_effort=(
                runtime.get("reasoningEffort")
                or _env("HICLAW_DROID_REASONING", DEFAULT_REASONING)
            ),
            spec_reasoning_effort=runtime.get("specReasoningEffort"),
            auto_level=(
                runtime.get("autoLevel")
                or _env("HICLAW_DROID_AUTO", DEFAULT_AUTO_LEVEL)
            ),
            use_spec=bool(runtime.get("useSpec", False)),
            mission=bool(runtime.get("mission", False)),
            worker_model=runtime.get("workerModel"),
            worker_reasoning_effort=runtime.get("workerReasoningEffort"),
            validator_model=runtime.get("validatorModel"),
            validator_reasoning_effort=runtime.get("validatorReasoningEffort"),
            cwd=_expand(cwd_raw),
            append_system_prompt_file=_expand(prompt_path) if prompt_path else None,
            append_system_prompt=runtime.get("appendSystemPrompt"),
            enabled_tools=_as_list(runtime.get("enabledTools")),
            disabled_tools=_as_list(runtime.get("disabledTools")),
            tags=_as_list(runtime.get("tags")) or ["hiclaw", "manager"],
            log_group_id=runtime.get("logGroupId") or _env("HICLAW_DROID_LOG_GROUP"),
            skip_permissions_unsafe=bool(
                runtime.get("skipPermissionsUnsafe", False)
                or _env("HICLAW_DROID_UNSAFE") == "1"
            ),
            session_dir=_expand(session_dir_raw),
            stall_timeout_seconds=int(
                runtime.get("stallTimeoutSeconds", DEFAULT_STALL_TIMEOUT)
            ),
            api_key_env=runtime.get("apiKeyEnv", "FACTORY_API_KEY"),
        )

    def build_argv(self) -> list[str]:
        """Compose the ``droid exec`` invocation as an argv list.

        We always run with ``--input-format stream-jsonrpc
        --output-format stream-jsonrpc`` so the harness can speak the
        documented JSON-RPC protocol over stdin/stdout.
        """
        argv: list[str] = [
            self.binary,
            "exec",
            "--input-format",
            "stream-jsonrpc",
            "--output-format",
            "stream-jsonrpc",
            "--auto",
            self.auto_level,
            "--cwd",
            str(self.cwd),
        ]
        if self.model:
            argv += ["-m", self.model]
        if self.spec_model:
            argv += ["--spec-model", self.spec_model]
        if self.reasoning_effort:
            argv += ["-r", self.reasoning_effort]
        if self.spec_reasoning_effort:
            argv += ["--spec-reasoning-effort", self.spec_reasoning_effort]
        if self.use_spec:
            argv += ["--use-spec"]
        if self.mission:
            argv += ["--mission"]
            if self.worker_model:
                argv += ["--worker-model", self.worker_model]
            if self.worker_reasoning_effort:
                argv += ["--worker-reasoning-effort", self.worker_reasoning_effort]
            if self.validator_model:
                argv += ["--validator-model", self.validator_model]
            if self.validator_reasoning_effort:
                argv += ["--validator-reasoning-effort", self.validator_reasoning_effort]
        if self.append_system_prompt_file:
            argv += [
                "--append-system-prompt-file",
                str(self.append_system_prompt_file),
            ]
        elif self.append_system_prompt:
            argv += ["--append-system-prompt", self.append_system_prompt]
        if self.enabled_tools:
            argv += ["--enabled-tools", ",".join(self.enabled_tools)]
        if self.disabled_tools:
            argv += ["--disabled-tools", ",".join(self.disabled_tools)]
        for tag in self.tags:
            argv += ["--tag", tag]
        if self.log_group_id:
            argv += ["--log-group-id", self.log_group_id]
        if self.skip_permissions_unsafe:
            argv += ["--skip-permissions-unsafe"]
        return argv


@dataclass
class RuntimeConfig:
    """The complete runtime config for the Droid Manager."""

    matrix: MatrixSettings
    droid: DroidConfig
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, openclaw_json: str | os.PathLike[str]) -> "RuntimeConfig":
        """Load an ``openclaw.json`` file from disk."""
        path = _expand(openclaw_json)
        if not path.is_file():
            raise FileNotFoundError(
                f"openclaw.json not found at {path}; the manager runtime needs "
                f"a populated config (see start-manager-agent.sh)"
            )
        raw = json.loads(path.read_text(encoding="utf-8"))
        return cls(
            matrix=MatrixSettings.from_openclaw(raw),
            droid=DroidConfig.from_openclaw(raw),
            raw=raw,
        )
