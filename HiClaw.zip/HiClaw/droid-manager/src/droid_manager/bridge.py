"""Bridge legacy openclaw.json into a droid-manager runtime layout.

Mirrors ``copaw_worker.bridge`` so the start script can call::

    python3 -m droid_manager.bridge \
        --openclaw-json /root/manager-workspace/openclaw.json \
        --working-dir /root/.droid-manager

The bridge produces:

    <working_dir>/runtime.droid.json   — the resolved DroidConfig as JSON
    <working_dir>/runtime.matrix.json  — the resolved MatrixSettings as JSON
    <working_dir>/sessions/            — directory for session-id persistence

These artifacts are not required at runtime (the manager re-reads
openclaw.json on boot), but they are useful for debugging and for tooling
that wants to inspect the resolved configuration without running the manager.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import os
import sys
from pathlib import Path

from .config import RuntimeConfig


def _to_json(obj: object) -> object:
    if dataclasses.is_dataclass(obj):
        return {
            k: _to_json(v) for k, v in dataclasses.asdict(obj).items()
        }
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, (list, tuple)):
        return [_to_json(v) for v in obj]
    if isinstance(obj, dict):
        return {k: _to_json(v) for k, v in obj.items()}
    return obj


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="droid_manager.bridge")
    parser.add_argument("--openclaw-json", required=True)
    parser.add_argument("--working-dir", required=True)
    parser.add_argument("--profile", default="manager", choices=["manager"])
    args = parser.parse_args(argv)

    working = Path(os.path.expandvars(os.path.expanduser(args.working_dir)))
    working.mkdir(parents=True, exist_ok=True)
    (working / "sessions").mkdir(parents=True, exist_ok=True)

    config = RuntimeConfig.load(args.openclaw_json)
    (working / "runtime.droid.json").write_text(
        json.dumps(_to_json(config.droid), indent=2), encoding="utf-8"
    )
    (working / "runtime.matrix.json").write_text(
        json.dumps(_to_json(config.matrix), indent=2), encoding="utf-8"
    )
    print(
        f"bridged {args.openclaw_json} -> {working}/runtime.{{droid,matrix}}.json",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
