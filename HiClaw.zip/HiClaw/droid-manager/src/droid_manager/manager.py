"""Main Droid Manager loop.

Owns one :class:`MatrixChannel` and one :class:`DroidHarness`, and routes
events between them:

    Matrix message  ──►  DroidHarness.add_user_message_stream(text=…)
    text_delta / text_complete events  ──►  Matrix room_send
    permission_request                 ──►  Matrix DM to admin (optional approval)
    turn_complete                      ──►  flush typing + read receipt

The manager maintains one droid session per Matrix room (DM or group),
persisted via :class:`SessionStore` so it survives container restarts.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
from pathlib import Path
from typing import Any, Optional

from .config import RuntimeConfig
from .harness import DroidHarness, HarnessEvent
from .matrix_channel import MatrixChannel, MatrixInbound
from .session_store import SessionRecord, SessionStore

logger = logging.getLogger("droid_manager.manager")

DEFAULT_OPENCLAW_JSON = "~/manager-workspace/openclaw.json"

# How often to send a typing indicator while a turn is streaming.
TYPING_REFRESH_S = 25
# Max characters per Matrix message — Matrix supports much more but Element
# truncates long messages. We chunk above this threshold.
MAX_REPLY_CHARS = 16_000


def _expand(path: str | os.PathLike[str]) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(path))))


class DroidManager:
    """Top-level orchestrator: Matrix ⇄ Droid harness."""

    def __init__(
        self,
        config: RuntimeConfig,
        *,
        openclaw_workspace: Optional[Path] = None,
    ) -> None:
        self._cfg = config
        self._workspace = openclaw_workspace or _expand("~/manager-workspace")
        sync_token = self._workspace / ".matrix_sync_token"
        e2ee_store = self._workspace / ".matrix_crypto_store"
        self._matrix = MatrixChannel(
            config.matrix,
            sync_token_path=sync_token,
            e2ee_store_path=e2ee_store,
        )
        self._harness = DroidHarness(
            config.droid,
            permission_resolver=self._resolve_permission,
            ask_user_resolver=self._resolve_ask_user,
        )
        self._sessions = SessionStore(config.droid.session_dir)
        # room_id -> task currently driving a turn for that room
        self._inflight: dict[str, asyncio.Task] = {}
        # room_id -> pending text buffer (for chunked streaming sends)
        self._buffers: dict[str, list[str]] = {}
        self._shutdown = asyncio.Event()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Run until SIGTERM / SIGINT."""
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, self._shutdown.set)
            except NotImplementedError:  # pragma: no cover - Windows
                pass

        await self._harness.start()
        await self._matrix.start()
        logger.info(
            "DroidManager up — matrix user=%s cwd=%s model=%s auto=%s",
            self._matrix.user_id,
            self._cfg.droid.cwd,
            self._cfg.droid.model or "<default>",
            self._cfg.droid.auto_level,
        )

        try:
            await asyncio.gather(self._dispatch_loop(), self._shutdown.wait())
        finally:
            await self.shutdown()

    async def shutdown(self) -> None:
        for task in list(self._inflight.values()):
            if not task.done():
                task.cancel()
        await self._matrix.stop()
        await self._harness.stop()

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    async def _dispatch_loop(self) -> None:
        """Pull inbound Matrix events and assign them to per-room workers."""
        while not self._shutdown.is_set():
            inbound = await self._matrix.inbound.get()
            existing = self._inflight.get(inbound.room_id)
            if existing and not existing.done():
                # Serialize turns per room: wait for current turn to finish
                # before starting the next one, so the droid session sees
                # messages in order.
                logger.debug(
                    "queuing inbound for %s (current turn in flight)",
                    inbound.room_id,
                )
                self._inflight[inbound.room_id] = asyncio.create_task(
                    self._after(existing, inbound)
                )
            else:
                self._inflight[inbound.room_id] = asyncio.create_task(
                    self._handle_inbound(inbound)
                )

    async def _after(self, prior: asyncio.Task, inbound: MatrixInbound) -> None:
        try:
            await prior
        except Exception:
            pass
        await self._handle_inbound(inbound)

    async def _handle_inbound(self, inbound: MatrixInbound) -> None:
        room_id = inbound.room_id
        try:
            await self._matrix.mark_read(room_id, inbound.event_id)
            await self._matrix.set_typing(room_id, True)
            session_id = await self._ensure_session(room_id, kind="dm" if inbound.is_dm else "room")
            await self._stream_turn(session_id, inbound)
        except Exception as exc:
            logger.exception("turn failed for %s: %s", room_id, exc)
            await self._matrix.send_reply(
                room_id, f"⚠️ droid harness error: {exc}"
            )
        finally:
            await self._matrix.set_typing(room_id, False)
            self._inflight.pop(room_id, None)

    async def _ensure_session(self, room_id: str, *, kind: str) -> str:
        existing = self._sessions.get(room_id)
        if existing and existing.session_id:
            try:
                sid = await self._harness.initialize_session(
                    resume_session_id=existing.session_id,
                    name=f"matrix:{room_id}",
                    metadata={"room_id": room_id, "kind": kind},
                )
                self._sessions.touch(room_id)
                return sid
            except Exception as exc:
                logger.warning(
                    "could not resume droid session %s for %s (%s); starting fresh",
                    existing.session_id,
                    room_id,
                    exc,
                )
        sid = await self._harness.initialize_session(
            name=f"matrix:{room_id}",
            metadata={"room_id": room_id, "kind": kind},
        )
        self._sessions.put(SessionRecord(room_id=room_id, session_id=sid, kind=kind))
        return sid

    async def _stream_turn(self, session_id: str, inbound: MatrixInbound) -> None:
        """Pump a single turn end-to-end."""
        text_buffer: list[str] = []
        sent_any = False
        typing_refresher = asyncio.create_task(self._typing_refresh(inbound.room_id))
        try:
            async for event in self._harness.add_user_message_stream(
                text=inbound.body, session_id=session_id
            ):
                await self._handle_event(inbound, event, text_buffer)
                if event.kind == "text_complete":
                    sent_any = True
                if event.kind == "turn_complete":
                    break
        finally:
            typing_refresher.cancel()
            try:
                await typing_refresher
            except (asyncio.CancelledError, Exception):
                pass

        # Flush any leftover streamed text that never got terminated by a
        # text_complete event (rare; some models only emit deltas).
        leftover = "".join(text_buffer).strip()
        if leftover and not sent_any:
            await self._send_chunked(inbound.room_id, leftover)

    async def _handle_event(
        self,
        inbound: MatrixInbound,
        event: HarnessEvent,
        text_buffer: list[str],
    ) -> None:
        room_id = inbound.room_id
        if event.kind == "text_delta":
            text_buffer.append(event.content)
        elif event.kind == "text_complete":
            content = event.content or "".join(text_buffer)
            text_buffer.clear()
            if content.strip():
                await self._send_chunked(room_id, content)
        elif event.kind == "tool_use":
            tool = event.payload.get("tool", "?")
            logger.info("droid tool_use room=%s tool=%s", room_id, tool)
        elif event.kind == "tool_result":
            logger.debug("droid tool_result room=%s", room_id)
        elif event.kind == "error":
            msg = event.payload.get("message") or "(unspecified error)"
            await self._matrix.send_reply(room_id, f"⚠️ droid error: {msg}")
        elif event.kind == "token_usage":
            logger.debug(
                "tokens room=%s in=%s out=%s",
                room_id,
                event.payload.get("input"),
                event.payload.get("output"),
            )

    async def _send_chunked(self, room_id: str, text: str) -> None:
        if len(text) <= MAX_REPLY_CHARS:
            await self._matrix.send_reply(room_id, text)
            return
        # Try to split on paragraph boundaries to keep messages readable.
        chunks: list[str] = []
        buf: list[str] = []
        size = 0
        for para in text.split("\n\n"):
            if size + len(para) + 2 > MAX_REPLY_CHARS and buf:
                chunks.append("\n\n".join(buf))
                buf = [para]
                size = len(para)
            else:
                buf.append(para)
                size += len(para) + 2
        if buf:
            chunks.append("\n\n".join(buf))
        for i, chunk in enumerate(chunks, 1):
            tail = f"\n\n_(part {i}/{len(chunks)})_" if len(chunks) > 1 else ""
            await self._matrix.send_reply(room_id, chunk + tail)

    async def _typing_refresh(self, room_id: str) -> None:
        try:
            while True:
                await asyncio.sleep(TYPING_REFRESH_S)
                await self._matrix.set_typing(room_id, True)
        except asyncio.CancelledError:
            return

    # ------------------------------------------------------------------
    # Server -> client resolvers
    # ------------------------------------------------------------------

    async def _resolve_permission(self, params: dict[str, Any]) -> dict[str, Any]:
        """Default policy: auto-grant when ``--auto`` already authorizes the tier.

        ``droid exec --auto medium`` already gates most prompts internally, so
        if we still get a ``request_permission`` callback it's for a tier above
        the configured autonomy level. We deny by default; operators can plug
        in a real approval flow (Matrix DM, Slack, web UI, etc.) by subclassing
        :class:`DroidManager` and overriding this method.
        """
        desc = params.get("description") or params.get("tool") or "?"
        # In skip_permissions_unsafe mode, grant everything.
        if self._cfg.droid.skip_permissions_unsafe:
            logger.warning("auto-granting permission (unsafe mode): %s", desc)
            return {"granted": True}
        logger.warning(
            "denying permission for %s — implement DroidManager._resolve_permission "
            "to wire approvals.",
            desc,
        )
        return {"granted": False, "reason": "no approval flow configured"}

    async def _resolve_ask_user(self, params: dict[str, Any]) -> dict[str, Any]:
        prompt = params.get("prompt") or ""
        logger.info("droid ask_user (no responder): %s", prompt)
        return {"answer": ""}


async def main_async(openclaw_json: str | os.PathLike[str] | None = None) -> None:
    path = openclaw_json or os.environ.get("OPENCLAW_CONFIG_PATH") or DEFAULT_OPENCLAW_JSON
    config = RuntimeConfig.load(path)
    manager = DroidManager(config)
    await manager.run()


def run(openclaw_json: str | os.PathLike[str] | None = None) -> None:
    asyncio.run(main_async(openclaw_json))
