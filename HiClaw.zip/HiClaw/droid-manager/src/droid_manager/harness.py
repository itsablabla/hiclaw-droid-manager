"""Subprocess + JSON-RPC stream wrapper around ``droid exec``.

Speaks the protocol documented in
https://docs.factory.ai/cli/droid-exec/overview:

* Spawn ``droid exec --input-format stream-jsonrpc --output-format stream-jsonrpc``.
* Each line written to stdin is one JSON-RPC request.
* Each line read from stdout is one JSON-RPC response, server request, or
  notification.
* ``droid.session_notification`` notifications stream assistant text deltas,
  tool events, token usage, errors, and ``turn_complete`` markers.
* The droid process may issue server-to-client requests like
  ``droid.request_permission`` and ``droid.ask_user`` that must be answered
  so the agent keeps making progress.

The harness exposes a clean async API:

    async with DroidHarness(cfg) as harness:
        session_id = await harness.initialize_session(name="matrix:!room")
        async for event in harness.add_user_message_stream(text="hi"):
            ...

It also auto-restarts the subprocess on unclean exit and surfaces
``HarnessEvent`` instances so the manager loop only has to care about
"text delta", "tool call", "turn finished", and "permission requested".
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import signal
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Awaitable, Callable, Dict, Optional

from .config import DroidConfig

logger = logging.getLogger("droid_manager.harness")

# JSON-RPC method names defined by the droid exec stream protocol.
METHOD_INITIALIZE = "droid.initialize_session"
METHOD_LOAD = "droid.load_session"
METHOD_FORK = "droid.fork_session"
METHOD_ADD_MSG = "droid.add_user_message"
METHOD_INTERRUPT = "droid.interrupt"
METHOD_COMPACT = "droid.compact_history"
METHOD_UPDATE_SETTINGS = "droid.update_settings"
METHOD_LIST_TOOLS = "droid.list_tools"

# Server -> client requests
SRV_REQUEST_PERMISSION = "droid.request_permission"
SRV_ASK_USER = "droid.ask_user"

# Server -> client notifications
NTF_SESSION = "droid.session_notification"


@dataclass
class HarnessRequest:
    """A pending JSON-RPC request awaiting a response from ``droid exec``."""

    id: str
    method: str
    params: dict[str, Any]
    future: asyncio.Future = field(default_factory=asyncio.Future)


@dataclass
class HarnessEvent:
    """Normalised event surfaced to the manager loop.

    ``kind`` is one of:
      * ``"text_delta"``         — partial assistant text (``content``)
      * ``"text_complete"``      — full assistant message (``content``)
      * ``"tool_use"``           — agent is calling a tool (``tool``, ``args``)
      * ``"tool_result"``        — tool returned (``tool``, ``result``)
      * ``"turn_complete"``      — turn ended; safe to reply to user
      * ``"permission_request"`` — droid wants approval (``request_id``, ``request``)
      * ``"ask_user"``           — droid wants out-of-band input (``request_id``, ``prompt``)
      * ``"error"``              — error notification (``message``)
      * ``"token_usage"``        — token usage update (``input``, ``output``)
    """

    kind: str
    session_id: str
    payload: dict[str, Any] = field(default_factory=dict)

    @property
    def content(self) -> str:
        return str(self.payload.get("content") or "")


PermissionResolver = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class DroidHarness:
    """Async, line-delimited JSON-RPC client for ``droid exec``.

    Lifecycle
    ---------
    1. ``await harness.start()`` — spawn the subprocess.
    2. ``await harness.initialize_session(name=…)`` — create or attach.
    3. ``async for ev in harness.add_user_message_stream(text=…)`` —
       send a turn, stream events until ``turn_complete``.
    4. ``await harness.stop()`` — terminate gracefully.
    """

    def __init__(
        self,
        config: DroidConfig,
        *,
        permission_resolver: PermissionResolver | None = None,
        ask_user_resolver: PermissionResolver | None = None,
    ) -> None:
        self._cfg = config
        self._proc: Optional[asyncio.subprocess.Process] = None
        self._reader_task: Optional[asyncio.Task] = None
        self._pending: Dict[str, HarnessRequest] = {}
        self._event_queues: Dict[str, asyncio.Queue[HarnessEvent | None]] = {}
        self._session_id: Optional[str] = None
        self._lock = asyncio.Lock()
        self._stopped = False
        self._restart_attempts = 0
        self._last_event_at = time.monotonic()
        self._permission_resolver = permission_resolver or self._default_deny
        self._ask_user_resolver = ask_user_resolver or self._default_unknown
        self._on_exit: Optional[Callable[[int | None], None]] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "DroidHarness":
        await self.start()
        return self

    async def __aexit__(self, *_exc: Any) -> None:
        await self.stop()

    async def start(self) -> None:
        """Spawn the ``droid exec`` subprocess."""
        if self._proc is not None:
            return
        if not shutil.which(self._cfg.binary):
            raise FileNotFoundError(
                f"droid binary '{self._cfg.binary}' not found on PATH. "
                f"Install with: curl -fsSL https://app.factory.ai/cli | sh"
            )
        argv = self._cfg.build_argv()
        env = os.environ.copy()
        api_key = env.get(self._cfg.api_key_env)
        if not api_key:
            logger.warning(
                "%s not set — droid exec may fail to authenticate. Generate "
                "an API key at app.factory.ai/settings/api-keys.",
                self._cfg.api_key_env,
            )

        # Ensure cwd exists. The Manager workspace is created earlier in
        # start-manager-agent.sh, but be defensive when running standalone.
        try:
            self._cfg.cwd.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            logger.debug("cwd mkdir failed (%s); droid may still start", exc)

        logger.info("Spawning droid harness: %s", " ".join(argv))
        self._proc = await asyncio.create_subprocess_exec(
            *argv,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(self._cfg.cwd),
            env=env,
        )
        self._reader_task = asyncio.create_task(self._read_loop())
        asyncio.create_task(self._stderr_loop())

    async def stop(self) -> None:
        """Terminate the subprocess and cancel readers."""
        self._stopped = True
        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
        proc = self._proc
        self._proc = None
        if proc and proc.returncode is None:
            try:
                proc.send_signal(signal.SIGTERM)
                await asyncio.wait_for(proc.wait(), timeout=10)
            except asyncio.TimeoutError:
                logger.warning("droid harness did not exit; killing")
                proc.kill()
                await proc.wait()
        # Drain pending futures with a CancelledError-like result
        for req in self._pending.values():
            if not req.future.done():
                req.future.set_exception(RuntimeError("harness stopped"))
        self._pending.clear()
        for q in self._event_queues.values():
            await q.put(None)
        self._event_queues.clear()

    # ------------------------------------------------------------------
    # Public RPC API
    # ------------------------------------------------------------------

    async def initialize_session(
        self,
        *,
        name: str | None = None,
        resume_session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Open a session and return its server-side id.

        If ``resume_session_id`` is provided, use ``droid.load_session``; this
        mirrors ``droid exec --session-id <id>`` and is how we reattach after
        a Manager container restart.
        """
        params: dict[str, Any] = {}
        if metadata:
            params["metadata"] = metadata
        if name:
            params["name"] = name
        if resume_session_id:
            method = METHOD_LOAD
            params["session_id"] = resume_session_id
        else:
            method = METHOD_INITIALIZE
        result = await self.request(method, params)
        session_id = result.get("session_id") or resume_session_id
        if not session_id:
            raise RuntimeError(f"{method} returned no session_id: {result!r}")
        self._session_id = session_id
        return session_id

    async def fork_session(self, source_session_id: str) -> str:
        """Fork an existing session and return the new session id."""
        result = await self.request(METHOD_FORK, {"session_id": source_session_id})
        new_id = result.get("session_id")
        if not new_id:
            raise RuntimeError(f"{METHOD_FORK} returned no session_id: {result!r}")
        return new_id

    async def interrupt(self, session_id: str | None = None) -> None:
        await self.request(METHOD_INTERRUPT, {"session_id": session_id or self._session_id})

    async def compact_history(self, prompt: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"session_id": self._session_id}
        if prompt:
            params["prompt"] = prompt
        return await self.request(METHOD_COMPACT, params)

    async def list_tools(self) -> list[dict[str, Any]]:
        result = await self.request(METHOD_LIST_TOOLS, {"session_id": self._session_id})
        return result.get("tools") or []

    async def add_user_message_stream(
        self,
        *,
        text: str,
        attachments: list[dict[str, Any]] | None = None,
        session_id: str | None = None,
    ) -> AsyncIterator[HarnessEvent]:
        """Send a user message and stream events until the turn completes.

        Yields ``HarnessEvent`` instances. The iterator terminates on
        ``turn_complete`` or when the subprocess exits unexpectedly.
        """
        sid = session_id or self._session_id
        if not sid:
            raise RuntimeError(
                "no session_id; call initialize_session() before add_user_message_stream()"
            )
        queue: asyncio.Queue[HarnessEvent | None] = asyncio.Queue()
        self._event_queues[sid] = queue
        params: dict[str, Any] = {"session_id": sid, "text": text}
        if attachments:
            params["attachments"] = attachments
        # Fire-and-forget request: progress arrives via notifications, and the
        # method itself returns a small ack we can ignore.
        asyncio.create_task(self._fire_and_forget(METHOD_ADD_MSG, params))
        while True:
            event = await queue.get()
            if event is None:
                self._event_queues.pop(sid, None)
                return
            yield event
            if event.kind == "turn_complete":
                self._event_queues.pop(sid, None)
                return

    async def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Send a single JSON-RPC request and await its response."""
        if not self._proc or not self._proc.stdin:
            raise RuntimeError("harness not started")
        rid = uuid.uuid4().hex
        req = HarnessRequest(id=rid, method=method, params=params)
        self._pending[rid] = req
        payload = {"jsonrpc": "2.0", "id": rid, "method": method, "params": params}
        await self._write_line(payload)
        try:
            return await asyncio.wait_for(req.future, timeout=120)
        except asyncio.TimeoutError as exc:
            self._pending.pop(rid, None)
            raise TimeoutError(f"droid harness timeout on {method}") from exc

    async def respond(
        self,
        request_id: str,
        *,
        result: dict[str, Any] | None = None,
        error: dict[str, Any] | None = None,
    ) -> None:
        """Reply to a server-to-client request (permission / ask_user)."""
        payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
        if error is not None:
            payload["error"] = error
        else:
            payload["result"] = result or {}
        await self._write_line(payload)

    # ------------------------------------------------------------------
    # Internal: read loop, write helper, notification routing
    # ------------------------------------------------------------------

    async def _fire_and_forget(self, method: str, params: dict[str, Any]) -> None:
        try:
            await self.request(method, params)
        except Exception as exc:
            logger.warning("droid harness %s failed: %s", method, exc)

    async def _write_line(self, payload: dict[str, Any]) -> None:
        if not self._proc or not self._proc.stdin:
            raise RuntimeError("harness stdin is closed")
        line = json.dumps(payload, ensure_ascii=False) + "\n"
        self._proc.stdin.write(line.encode("utf-8"))
        try:
            await self._proc.stdin.drain()
        except (BrokenPipeError, ConnectionResetError) as exc:
            logger.error("droid harness stdin broken: %s", exc)
            await self._handle_unclean_exit()

    async def _read_loop(self) -> None:
        assert self._proc and self._proc.stdout
        try:
            while True:
                line = await self._proc.stdout.readline()
                if not line:
                    break
                self._last_event_at = time.monotonic()
                try:
                    msg = json.loads(line.decode("utf-8", errors="replace").strip() or "{}")
                except json.JSONDecodeError as exc:
                    logger.debug("droid harness sent non-JSON line: %r (%s)", line, exc)
                    continue
                await self._handle_message(msg)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("droid harness read loop crashed: %s", exc)
        finally:
            await self._handle_unclean_exit()

    async def _stderr_loop(self) -> None:
        if not self._proc or not self._proc.stderr:
            return
        try:
            while True:
                line = await self._proc.stderr.readline()
                if not line:
                    return
                logger.warning("droid stderr: %s", line.decode("utf-8", errors="replace").rstrip())
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.debug("stderr loop ended: %s", exc)

    async def _handle_message(self, msg: dict[str, Any]) -> None:
        # 1. Response to one of our requests
        if "id" in msg and ("result" in msg or "error" in msg):
            rid = str(msg["id"])
            req = self._pending.pop(rid, None)
            if req and not req.future.done():
                if "error" in msg:
                    req.future.set_exception(
                        RuntimeError(f"droid {req.method} error: {msg['error']}")
                    )
                else:
                    req.future.set_result(msg.get("result") or {})
            return

        method = msg.get("method")
        params = msg.get("params") or {}

        # 2. Server-to-client request
        if method in (SRV_REQUEST_PERMISSION, SRV_ASK_USER) and "id" in msg:
            await self._handle_server_request(str(msg["id"]), method, params)
            return

        # 3. Notification
        if method == NTF_SESSION:
            self._dispatch_session_notification(params)
            return

        logger.debug("droid harness unhandled msg: %s", msg)

    async def _handle_server_request(
        self,
        request_id: str,
        method: str,
        params: dict[str, Any],
    ) -> None:
        try:
            if method == SRV_REQUEST_PERMISSION:
                result = await self._permission_resolver(params)
            else:  # SRV_ASK_USER
                result = await self._ask_user_resolver(params)
            await self.respond(request_id, result=result)
        except Exception as exc:
            logger.exception("server-request handler failed: %s", exc)
            await self.respond(
                request_id,
                error={"code": -32000, "message": f"handler error: {exc}"},
            )

    def _dispatch_session_notification(self, params: dict[str, Any]) -> None:
        """Translate a raw notification into a typed ``HarnessEvent``."""
        sid = params.get("session_id") or self._session_id or ""
        queue = self._event_queues.get(sid)
        if queue is None:
            return
        kind = params.get("type") or params.get("event") or ""
        event: HarnessEvent | None = None
        if kind in ("text_delta", "assistant_text_delta"):
            event = HarnessEvent("text_delta", sid, {"content": params.get("delta", "")})
        elif kind in ("text_complete", "assistant_message", "message"):
            event = HarnessEvent(
                "text_complete", sid, {"content": params.get("text", "")}
            )
        elif kind in ("tool_use", "tool_call"):
            event = HarnessEvent(
                "tool_use",
                sid,
                {"tool": params.get("name", ""), "args": params.get("arguments", {})},
            )
        elif kind in ("tool_result", "tool_response"):
            event = HarnessEvent(
                "tool_result",
                sid,
                {"tool": params.get("name", ""), "result": params.get("result", "")},
            )
        elif kind in ("turn_complete", "turn_end", "done"):
            event = HarnessEvent("turn_complete", sid, dict(params))
        elif kind in ("error",):
            event = HarnessEvent("error", sid, {"message": params.get("message", "")})
        elif kind in ("token_usage", "usage"):
            event = HarnessEvent(
                "token_usage",
                sid,
                {
                    "input": params.get("input_tokens", 0),
                    "output": params.get("output_tokens", 0),
                },
            )
        else:
            event = HarnessEvent(kind or "unknown", sid, dict(params))
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:  # pragma: no cover
            logger.warning("event queue full for session %s", sid)

    async def _handle_unclean_exit(self) -> None:
        if self._stopped:
            return
        proc = self._proc
        if proc is None:
            return
        code = proc.returncode
        logger.warning("droid harness exited (code=%s); attempting restart", code)
        # Flush pending futures
        for req in list(self._pending.values()):
            if not req.future.done():
                req.future.set_exception(RuntimeError(f"droid harness exited (code={code})"))
        self._pending.clear()
        for sid, q in list(self._event_queues.items()):
            await q.put(HarnessEvent("error", sid, {"message": f"harness exited code={code}"}))
            await q.put(None)
        self._event_queues.clear()
        self._proc = None
        if self._on_exit:
            try:
                self._on_exit(code)
            except Exception:
                logger.exception("on_exit callback raised")

    # ------------------------------------------------------------------
    # Default resolvers — overridable from DroidManager
    # ------------------------------------------------------------------

    @staticmethod
    async def _default_deny(params: dict[str, Any]) -> dict[str, Any]:
        """Deny permission by default for safety; manager.py overrides this."""
        logger.warning(
            "droid requested permission but no resolver is wired; denying: %s",
            params.get("description") or params,
        )
        return {"granted": False, "reason": "no resolver configured"}

    @staticmethod
    async def _default_unknown(params: dict[str, Any]) -> dict[str, Any]:
        """Default ``ask_user`` resolver — return an empty answer."""
        logger.info("droid ask_user (no resolver): %s", params.get("prompt"))
        return {"answer": ""}
