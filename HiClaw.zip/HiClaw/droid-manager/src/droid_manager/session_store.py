"""Persistent map from Matrix room/DM identity to a droid session id.

Each session id is written to ``${session_dir}/<safe_name>.json`` so we can
re-attach to the same droid context after a Manager container restart.

File layout (one JSON file per room/DM)::

    {
        "room_id": "!abc123:hiclaw.example",
        "session_id": "8af22e0a-d222-42c6-8c7e-7a059e391b0b",
        "created_at": 1716350123,
        "last_used_at": 1716350987,
        "kind": "dm"
    }
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger("droid_manager.sessions")


def _safe_filename(name: str) -> str:
    """Map an arbitrary string to a filesystem-safe file name."""
    safe = []
    for ch in name:
        if ch.isalnum() or ch in ("-", "_", "."):
            safe.append(ch)
        else:
            safe.append("_")
    out = "".join(safe).strip("_") or "default"
    return out[:200]  # keep well under typical 255-byte limit


@dataclass
class SessionRecord:
    room_id: str
    session_id: str
    created_at: int = field(default_factory=lambda: int(time.time()))
    last_used_at: int = field(default_factory=lambda: int(time.time()))
    kind: str = "room"  # "dm" or "room"
    extra: dict = field(default_factory=dict)


class SessionStore:
    """File-backed session map. Thread-unsafe; called from the async loop."""

    def __init__(self, directory: str | os.PathLike[str]) -> None:
        self._dir = Path(os.path.expandvars(os.path.expanduser(str(directory))))
        self._dir.mkdir(parents=True, exist_ok=True)

    def _path_for(self, room_id: str) -> Path:
        return self._dir / f"{_safe_filename(room_id)}.json"

    def get(self, room_id: str) -> Optional[SessionRecord]:
        path = self._path_for(room_id)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("session_store: read %s failed: %s", path, exc)
            return None
        return SessionRecord(
            room_id=data.get("room_id", room_id),
            session_id=data.get("session_id", ""),
            created_at=int(data.get("created_at", time.time())),
            last_used_at=int(data.get("last_used_at", time.time())),
            kind=data.get("kind", "room"),
            extra=data.get("extra") or {},
        )

    def put(self, record: SessionRecord) -> None:
        path = self._path_for(record.room_id)
        try:
            path.write_text(json.dumps(asdict(record), indent=2), encoding="utf-8")
        except OSError as exc:
            logger.warning("session_store: write %s failed: %s", path, exc)

    def touch(self, room_id: str) -> None:
        existing = self.get(room_id)
        if existing is None:
            return
        existing.last_used_at = int(time.time())
        self.put(existing)

    def delete(self, room_id: str) -> None:
        path = self._path_for(room_id)
        try:
            path.unlink(missing_ok=True)
        except OSError as exc:
            logger.debug("session_store: delete %s failed: %s", path, exc)

    def all(self) -> list[SessionRecord]:
        out: list[SessionRecord] = []
        for path in self._dir.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                out.append(SessionRecord(**{k: v for k, v in data.items() if k in SessionRecord.__annotations__}))
            except Exception:
                continue
        return out
