"""Unit tests for :mod:`droid_manager.config`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from droid_manager.config import DroidConfig, MatrixSettings, RuntimeConfig


SAMPLE = {
    "channels": {
        "matrix": {
            "enabled": True,
            "homeserver": "https://matrix.example.com",
            "accessToken": "syt_token_xxx",
            "userId": "@manager:matrix.example.com",
            "encryption": True,
            "dm": {
                "policy": "allowlist",
                "allowFrom": ["@jaden:matrix.example.com"],
            },
            "groupPolicy": "allowlist",
            "groupAllowFrom": ["@jaden:matrix.example.com"],
            "groups": {"*": {"requireMention": True}},
            "autoJoin": "always",
        }
    },
    "runtime": {
        "droid": {
            "model": "claude-sonnet-4-6",
            "specModel": "claude-haiku-4-5",
            "reasoningEffort": "high",
            "autoLevel": "high",
            "useSpec": True,
            "mission": True,
            "workerModel": "claude-sonnet-4-6",
            "validatorModel": "claude-opus-4-7",
            "appendSystemPromptFile": "/tmp/SOUL.md",
            "enabledTools": ["ApplyPatch", "Bash"],
            "disabledTools": ["execute-cli"],
            "tags": ["hiclaw", "manager", "test"],
            "logGroupId": "hiclaw-manager-test",
            "cwd": "/tmp/manager",
            "sessionDir": "/tmp/sessions",
            "skipPermissionsUnsafe": False,
        }
    },
}


def test_matrix_settings_from_openclaw():
    m = MatrixSettings.from_openclaw(SAMPLE)
    assert m.homeserver == "https://matrix.example.com"
    assert m.access_token == "syt_token_xxx"
    assert m.user_id == "@manager:matrix.example.com"
    assert m.encryption is True
    assert m.dm_policy == "allowlist"
    assert "@jaden:matrix.example.com" in m.allow_from
    assert m.groups["*"]["requireMention"] is True


def test_droid_config_from_openclaw_full():
    d = DroidConfig.from_openclaw(SAMPLE)
    assert d.model == "claude-sonnet-4-6"
    assert d.auto_level == "high"
    assert d.use_spec is True
    assert d.mission is True
    assert "ApplyPatch" in d.enabled_tools
    assert "execute-cli" in d.disabled_tools
    assert d.tags == ["hiclaw", "manager", "test"]
    assert str(d.cwd) == "/tmp/manager"
    assert str(d.session_dir) == "/tmp/sessions"


def test_droid_config_defaults_when_block_missing():
    """A bare openclaw.json with no runtime block must still produce a config."""
    d = DroidConfig.from_openclaw({"channels": {"matrix": {}}})
    assert d.auto_level in {"low", "medium", "high"}
    assert d.reasoning_effort
    assert d.binary == "droid"
    assert d.session_dir is not None


def test_build_argv_includes_required_flags():
    d = DroidConfig.from_openclaw(SAMPLE)
    argv = d.build_argv()
    assert argv[0] == d.binary
    assert argv[1] == "exec"
    # stream-jsonrpc is the protocol the harness expects
    assert "--input-format" in argv
    assert "stream-jsonrpc" in argv
    assert "--output-format" in argv
    assert "--auto" in argv
    assert "high" in argv
    assert "-m" in argv
    assert "claude-sonnet-4-6" in argv
    assert "--mission" in argv
    assert "--use-spec" in argv
    assert "--tag" in argv
    assert "--enabled-tools" in argv
    assert "ApplyPatch,Bash" in argv
    assert "--cwd" in argv


def test_build_argv_omits_optional_flags():
    d = DroidConfig.from_openclaw({"channels": {"matrix": {}}})
    argv = d.build_argv()
    # No mission / use_spec / append_system_prompt
    assert "--mission" not in argv
    assert "--use-spec" not in argv
    # Default auto level is medium
    assert "medium" in argv


def test_runtime_config_load(tmp_path: Path):
    p = tmp_path / "openclaw.json"
    p.write_text(json.dumps(SAMPLE), encoding="utf-8")
    cfg = RuntimeConfig.load(p)
    assert cfg.matrix.homeserver == "https://matrix.example.com"
    assert cfg.droid.model == "claude-sonnet-4-6"


def test_runtime_config_load_missing(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        RuntimeConfig.load(tmp_path / "no.json")


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("HICLAW_DROID_MODEL", "gpt-5.4")
    monkeypatch.setenv("HICLAW_DROID_AUTO", "low")
    d = DroidConfig.from_openclaw({"channels": {"matrix": {}}})
    assert d.model == "gpt-5.4"
    assert d.auto_level == "low"
