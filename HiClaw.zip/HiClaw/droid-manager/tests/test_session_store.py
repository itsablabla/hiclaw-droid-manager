"""Unit tests for :mod:`droid_manager.session_store`."""

from __future__ import annotations

from pathlib import Path

from droid_manager.session_store import SessionRecord, SessionStore


def test_put_and_get(tmp_path: Path):
    store = SessionStore(tmp_path)
    rec = SessionRecord(
        room_id="!abc:matrix.example.com",
        session_id="droid-session-uuid-1",
        kind="dm",
    )
    store.put(rec)
    got = store.get("!abc:matrix.example.com")
    assert got is not None
    assert got.session_id == "droid-session-uuid-1"
    assert got.kind == "dm"


def test_get_unknown_returns_none(tmp_path: Path):
    store = SessionStore(tmp_path)
    assert store.get("!missing:matrix") is None


def test_touch_updates_last_used(tmp_path: Path):
    store = SessionStore(tmp_path)
    store.put(SessionRecord(room_id="!r:hs", session_id="sid"))
    before = store.get("!r:hs")
    assert before is not None
    store.touch("!r:hs")
    after = store.get("!r:hs")
    assert after is not None
    assert after.last_used_at >= before.last_used_at


def test_delete(tmp_path: Path):
    store = SessionStore(tmp_path)
    store.put(SessionRecord(room_id="!r:hs", session_id="sid"))
    store.delete("!r:hs")
    assert store.get("!r:hs") is None


def test_filename_sanitization(tmp_path: Path):
    """Room IDs with ``!`` / ``:`` / ``$`` must round-trip without filesystem errors."""
    store = SessionStore(tmp_path)
    weird = "!complex/room:host.with.dots:8080"
    store.put(SessionRecord(room_id=weird, session_id="sid-1"))
    got = store.get(weird)
    assert got is not None
    assert got.session_id == "sid-1"


def test_all_lists_existing_records(tmp_path: Path):
    store = SessionStore(tmp_path)
    store.put(SessionRecord(room_id="!a:hs", session_id="s1"))
    store.put(SessionRecord(room_id="!b:hs", session_id="s2", kind="dm"))
    records = sorted(store.all(), key=lambda r: r.session_id)
    assert [r.session_id for r in records] == ["s1", "s2"]
