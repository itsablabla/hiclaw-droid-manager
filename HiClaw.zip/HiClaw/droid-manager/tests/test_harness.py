"""Unit tests for :mod:`droid_manager.harness`.

These tests use a stub binary that speaks the documented JSON-RPC protocol
over stdin/stdout, so we exercise the harness without depending on the
real ``droid`` CLI.
"""

from __future__ import annotations

import asyncio
import json
import os
import stat
import textwrap
from pathlib import Path

import pytest

from droid_manager.config import DroidConfig
from droid_manager.harness import DroidHarness


def _write_stub(tmp_path: Path, body: str) -> Path:
    stub = tmp_path / "droid"
    script = "#!/usr/bin/env python3\n" + body
    stub.write_text(script, encoding="utf-8")
    stub.chmod(stub.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return stub


@pytest.mark.asyncio
async def test_initialize_session_returns_id(tmp_path: Path):
    stub = _write_stub(
        tmp_path,
        textwrap.dedent(
            """
            import json, sys
            for line in sys.stdin:
                req = json.loads(line)
                if req.get("method") == "droid.initialize_session":
                    resp = {"jsonrpc": "2.0", "id": req["id"], "result": {"session_id": "test-session-42"}}
                    sys.stdout.write(json.dumps(resp) + "\\n")
                    sys.stdout.flush()
            """
        ),
    )
    cfg = DroidConfig(binary=str(stub), cwd=tmp_path)
    async with DroidHarness(cfg) as harness:
        sid = await harness.initialize_session(name="test")
        assert sid == "test-session-42"


@pytest.mark.asyncio
async def test_add_user_message_streams_until_turn_complete(tmp_path: Path):
    stub = _write_stub(
        tmp_path,
        textwrap.dedent(
            """
            import json, sys
            for line in sys.stdin:
                req = json.loads(line)
                m = req.get("method")
                if m == "droid.initialize_session":
                    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": req["id"], "result": {"session_id": "s1"}}) + "\\n")
                    sys.stdout.flush()
                elif m == "droid.add_user_message":
                    # Emit a sequence of notifications, then ack the request.
                    notes = [
                        {"jsonrpc": "2.0", "method": "droid.session_notification", "params": {"session_id": "s1", "type": "text_delta", "delta": "hello "}},
                        {"jsonrpc": "2.0", "method": "droid.session_notification", "params": {"session_id": "s1", "type": "text_delta", "delta": "world"}},
                        {"jsonrpc": "2.0", "method": "droid.session_notification", "params": {"session_id": "s1", "type": "text_complete", "text": "hello world"}},
                        {"jsonrpc": "2.0", "method": "droid.session_notification", "params": {"session_id": "s1", "type": "turn_complete"}},
                    ]
                    for n in notes:
                        sys.stdout.write(json.dumps(n) + "\\n")
                        sys.stdout.flush()
                    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": req["id"], "result": {}}) + "\\n")
                    sys.stdout.flush()
            """
        ),
    )
    cfg = DroidConfig(binary=str(stub), cwd=tmp_path)
    async with DroidHarness(cfg) as harness:
        sid = await harness.initialize_session(name="test")
        events = []
        async for ev in harness.add_user_message_stream(text="hi", session_id=sid):
            events.append(ev)
        kinds = [e.kind for e in events]
        assert "text_delta" in kinds
        assert "text_complete" in kinds
        assert kinds[-1] == "turn_complete"
        completed = [e for e in events if e.kind == "text_complete"]
        assert completed[0].content == "hello world"


@pytest.mark.asyncio
async def test_permission_request_is_resolved(tmp_path: Path):
    stub = _write_stub(
        tmp_path,
        textwrap.dedent(
            """
            import json, sys
            # Send a server->client permission request, then wait for the response.
            req_id = "perm-1"
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": req_id, "method": "droid.request_permission", "params": {"tool": "Bash", "description": "rm -rf /"}}) + "\\n")
            sys.stdout.flush()
            for line in sys.stdin:
                msg = json.loads(line)
                if msg.get("id") == req_id:
                    sys.stdout.write(json.dumps({"resolved": msg.get("result")}) + "\\n")
                    sys.stdout.flush()
                    break
            """
        ),
    )

    resolutions = []

    async def resolver(params):
        resolutions.append(params)
        return {"granted": True, "reason": "test"}

    cfg = DroidConfig(binary=str(stub), cwd=tmp_path)
    harness = DroidHarness(cfg, permission_resolver=resolver)
    await harness.start()
    # Give the stub a beat to emit and read.
    await asyncio.sleep(0.5)
    await harness.stop()
    assert resolutions, "permission resolver was not invoked"
    assert resolutions[0]["tool"] == "Bash"


@pytest.mark.asyncio
async def test_missing_binary_raises(tmp_path: Path):
    cfg = DroidConfig(binary="droid-does-not-exist-xyz", cwd=tmp_path)
    harness = DroidHarness(cfg)
    with pytest.raises(FileNotFoundError):
        await harness.start()
