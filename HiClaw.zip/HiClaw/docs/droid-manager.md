# Droid Manager runtime

The **Droid Manager** is a third Manager runtime for HiClaw, alongside the
default OpenClaw (Node.js) and CoPaw (Python) harnesses. It replaces the
Manager's brain with the [Factory.ai Droid CLI](https://docs.factory.ai/welcome)
while keeping every other HiClaw contract intact — Workers, Matrix, Higress,
MinIO, and the controller all behave exactly as before.

## When to use it

* You already pay for a Factory.ai subscription and want HiClaw Managers to
  reuse your Droid models, skills, plugins, and MCP servers.
* You want Factory's autonomy levels (`low|medium|high`), Mission mode, and
  Spec mode as first-class Manager primitives.
* You want to centralize Manager observability through Factory's session
  tags + log groups.

## How it works

```
Matrix room ─► MatrixChannel (matrix-nio)
                       │
                       ▼
              DroidManager (asyncio)
                       │
                       ▼
              DroidHarness  ─────────► droid exec
                       │              --input-format stream-jsonrpc
                       │              --output-format stream-jsonrpc
                       │              --cwd /root/manager-workspace
                       │
                       ▼
              Persistent session ids per room
              under ~/.droid-manager/sessions/
```

Inbound Matrix messages are forwarded to `droid.add_user_message` over the
JSON-RPC stream defined by [Droid Exec → stream-jsonrpc](https://docs.factory.ai/cli/droid-exec/overview).
The manager pumps `droid.session_notification` events back into Matrix as
markdown replies, refreshes the typing indicator every 25s while a turn is
in flight, chunks responses longer than 16,000 characters, and persists the
Droid session id so the same context is reused after a container restart.

## Enabling the runtime

### Local Docker (embedded controller)

```bash
hiclaw-install.sh \
    --manager-runtime droid \
    --droid-api-key "$FACTORY_API_KEY" \
    --droid-model claude-sonnet-4-6 \
    --droid-auto medium
```

### Helm

```bash
helm install hiclaw ./helm/hiclaw \
    --set manager.runtime=droid \
    --set manager.droid.apiKey=$FACTORY_API_KEY \
    --set manager.droid.model=claude-sonnet-4-6 \
    --set manager.droid.autoLevel=medium
```

### Environment variables

| Variable                  | Purpose                                          |
| ------------------------- | ------------------------------------------------ |
| `HICLAW_MANAGER_RUNTIME`  | Set to `droid` to select this runtime            |
| `FACTORY_API_KEY`         | Factory.ai API key (required)                    |
| `HICLAW_DROID_MODEL`      | Override Droid model id                          |
| `HICLAW_DROID_AUTO`       | Autonomy level (`low|medium|high`)               |
| `HICLAW_DROID_REASONING`  | `off|none|low|medium|high`                       |
| `HICLAW_DROID_LOG_GROUP`  | Factory log group id for session filtering       |
| `HICLAW_DROID_UNSAFE`     | `1` to add `--skip-permissions-unsafe`           |
| `HICLAW_DROID_CWD`        | Working directory passed to `droid exec --cwd`   |
| `HICLAW_DROID_PROMPT_FILE`| File appended to the Droid system prompt         |

### `openclaw.json` block

The runtime reads the optional `runtime.droid` block from the same
`openclaw.json` that the OpenClaw harness consumes:

```jsonc
{
  "runtime": {
    "droid": {
      "model": "claude-sonnet-4-6",
      "autoLevel": "medium",
      "reasoningEffort": "medium",
      "useSpec": false,
      "mission": false,
      "cwd": "/root/manager-workspace",
      "appendSystemPromptFile": "/root/manager-workspace/SOUL.md",
      "enabledTools": [],
      "disabledTools": [],
      "tags": ["hiclaw", "manager"],
      "logGroupId": "hiclaw-manager",
      "sessionDir": "/root/.droid-manager/sessions",
      "stallTimeoutSeconds": 1800
    }
  }
}
```

## Permissions & autonomy

Droid runs by default in **Spec mode** (read-only). The Droid Manager opts
into mutating operations via `--auto medium` (matches the OpenClaw / CoPaw
default of `tools.exec.security="full"`).

When Droid asks for an above-autonomy permission, the Manager's default
resolver denies the request and surfaces the prompt in the container log.
Wire your own approval flow by subclassing `DroidManager` and overriding
`_resolve_permission`:

```python
from droid_manager.manager import DroidManager

class ApprovingManager(DroidManager):
    async def _resolve_permission(self, params):
        # Forward to the admin via a Matrix DM, Slack message, etc.
        granted = await ask_admin_via_matrix(params)
        return {"granted": granted}
```

## Sessions

Each Matrix room / DM gets its own persistent Droid session under
`~/.droid-manager/sessions/<safe_room_id>.json`. After a container restart,
the manager calls `droid.load_session` with the saved id so the agent
continues exactly where it left off. Reset a single room's context by
deleting that JSON file (or by sending `/reset` once we wire that through).

## Observability

Every Droid session is tagged with `hiclaw` + `manager` and attached to
the `hiclaw-manager` log group by default (overridable via `tags` and
`logGroupId` in the config). That makes Manager activity searchable in the
Factory dashboard alongside any other Droid sessions you run elsewhere.

## Limitations

* Currently the Manager runs one Droid session per room. Cross-room context
  is not shared — by design, mirroring OpenClaw's `dmScope: per-channel-peer`.
* The Worker runtimes (OpenClaw / CoPaw / Hermes) are unchanged. Droid
  Workers would be a future addition and would live under a sibling
  `droid-worker` package.
* Image, audio, and video uploads from Matrix are not yet routed into
  `droid.add_user_message` attachments — text only for now.
* `droid.fork_session` is wired but not used by default; future work will
  let the Manager fan-out exploratory branches without polluting the main
  room session.

## Troubleshooting

`droid binary 'droid' not found on PATH`
:   The image build did not run `scripts/install-droid-cli.sh`. Re-run the
    image build, or shell into the container and install manually:
    `npm install -g droid`.

`FACTORY_API_KEY is unset`
:   Generate a key at `app.factory.ai/settings/api-keys` and inject it via
    `--droid-api-key` (installer) or the `HICLAW_DROID_API_KEY` env var.

`droid harness exited (code=2)`
:   Exit code 2 is "invalid CLI arguments". Check the resolved invocation
    that the start script logs (`Spawning droid harness: droid exec …`).

`turn never completes`
:   The harness uses a 120s per-request timeout and surfaces an error event
    that the Manager replies with as `⚠️ droid error: …`. Raise
    `stallTimeoutSeconds` in the config block for long missions.
